const extractBtn = document.getElementById('extractBtn');
const statusEl   = document.getElementById('status');
const statusMsg  = document.getElementById('statusMsg');
const tokenWrap  = document.getElementById('tokenWrap');
const tokenBox   = document.getElementById('tokenBox');
const copyBtn    = document.getElementById('copyBtn');
const clearBtn   = document.getElementById('clearBtn');

// ✏️ แก้ไข URL ที่ต้องการให้ใช้ได้ที่นี่ (ใส่ได้หลาย URL)
const ALLOWED_URLS = [
  'https://your-site.com',
  // 'https://another-site.com',
];

function showStatus(type, msg) {
  statusEl.className = 'status ' + type;
  statusMsg.textContent = msg;
}

function showToken(token) {
  const hasQuotes = token.includes('"');
  const cleaned = token.replace(/"/g, '');
  tokenBox.textContent = cleaned;
  tokenBox.classList.toggle('has-quotes', hasQuotes);
  tokenWrap.style.display = 'flex';
  if (hasQuotes) {
    showStatus('warning', 'พบ " ในค่า token · ลบออกให้แล้ว');
  }
}

function hideToken() {
  tokenWrap.style.display = 'none';
  tokenBox.textContent = '';
  tokenBox.classList.remove('has-quotes');
}

extractBtn.addEventListener('click', async () => {
  extractBtn.disabled = true;
  extractBtn.innerHTML = '<span class="spinner"></span>EXTRACTING…';
  statusEl.className = 'status';
  hideToken();

  try {
    const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });

    // ตรวจสอบแค่ domain โดยไม่สนใจ path เช่น fs.com/index.html ก็ผ่าน
    const tabHost = tab.url ? new URL(tab.url).hostname : '';
    const isAllowed = ALLOWED_URLS.some(url => {
      try {
        const allowedHost = new URL(url.includes('://') ? url : 'https://' + url).hostname;
        return tabHost === allowedHost || tabHost.endsWith('.' + allowedHost);
      } catch { return false; }
    });
    if (!isAllowed) {
      showStatus('error', 'ไม่รองรับหน้านี้ · Allowed sites only');
      extractBtn.disabled = false;
      extractBtn.innerHTML = 'EXTRACT TOKEN';
      return;
    }

    const results = await chrome.scripting.executeScript({
      target: { tabId: tab.id },
      func: () => {
        try {
          // Try direct localStorage first
          const direct = localStorage.getItem('token');
          if (direct) return { token: direct.replace(/'/g, ''), source: 'direct' };

          // Fallback: use iframe (original bookmarklet approach)
          const iframe = document.createElement('iframe');
          iframe.style.display = 'none';
          document.body.appendChild(iframe);
          const iframeToken = iframe.contentWindow.localStorage.token;
          document.body.removeChild(iframe);

          if (iframeToken) return { token: iframeToken.replace(/'/g, ''), source: 'iframe' };

          // Scan all localStorage keys for anything that looks like a token
          for (let i = 0; i < localStorage.length; i++) {
            const key = localStorage.key(i);
            if (/token|auth|jwt|bearer/i.test(key)) {
              return { token: localStorage.getItem(key).replace(/'/g, ''), source: key };
            }
          }

          return { token: null };
        } catch (e) {
          return { error: e.message };
        }
      }
    });

    const result = results?.[0]?.result;

    if (result?.error) {
      showStatus('error', 'Script error: ' + result.error);
    } else if (result?.token) {
      showStatus('success', 'Token found via ' + result.source);
      showToken(result.token);
    } else {
      showStatus('error', 'No token found in localStorage');
    }

  } catch (err) {
    showStatus('error', err.message || 'Cannot access this page');
  } finally {
    extractBtn.disabled = false;
    extractBtn.innerHTML = 'EXTRACT TOKEN';
  }
});

copyBtn.addEventListener('click', async () => {
  const token = tokenBox.textContent;
  if (!token) return;

  try {
    await navigator.clipboard.writeText(token);
    copyBtn.textContent = '✓ Copied!';
    copyBtn.classList.add('copied');
    setTimeout(() => {
      copyBtn.textContent = '⎘ Copy';
      copyBtn.classList.remove('copied');
    }, 2000);
  } catch {
    // Fallback
    const ta = document.createElement('textarea');
    ta.value = token;
    document.body.appendChild(ta);
    ta.select();
    document.execCommand('copy');
    document.body.removeChild(ta);
    copyBtn.textContent = '✓ Copied!';
    setTimeout(() => { copyBtn.textContent = '⎘ Copy'; }, 2000);
  }
});

clearBtn.addEventListener('click', () => {
  hideToken();
  statusEl.className = 'status';
});
